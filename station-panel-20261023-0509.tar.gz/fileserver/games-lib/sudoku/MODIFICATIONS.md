# 本地化修改记录 · Sudoku JS

来源：https://github.com/baruchel/sudoku-js
版本：e9df285 (2017-02-22)
许可证：MIT License（MIT）

为在内网工作站离线托管，只做了以下**技术性**改动，未修改游戏逻辑、未移除版权声明：

- 入口文件 sudoku.html 复制为 index.html（静态目录默认 index.html）
- 保留上游 LICENSE 原文（LICENSE）

> 原仓库的 LICENSE/README 原样保留；本文件仅记录差异。

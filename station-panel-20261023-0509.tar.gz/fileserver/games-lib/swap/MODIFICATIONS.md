# 本地化修改记录 · Swap

来源：https://github.com/nmoroze/swap
版本：a3cfb7d (2018-02-16)
许可证：Creative Commons Attribution-ShareAlike 4.0（CC-BY-SA-4.0）

为在内网工作站离线托管，只做了以下**技术性**改动，未修改游戏逻辑、未移除版权声明：

- AddThis 外链移除后补一个空 stub，避免页面 JS 报 addthis is not defined
- 移除 Google Fonts 外链（改用系统字体栈）
- Font Awesome 4.0.3 → 本地 vendor/font-awesome/（MIT + SIL OFL 1.1）
- 移除 AddThis 社交统计脚本
- 移除 GitHub 丝带远程图片
- 保留上游 LICENSE 原文（LICENSE）
- 内置第三方库 vendor/font-awesome/css/font-awesome.min.css
- 内置第三方库 vendor/font-awesome/fonts/fontawesome-webfont.woff

> 原仓库的 LICENSE/README 原样保留；本文件仅记录差异。

# 本地化修改记录 · A Dark Room

来源：https://github.com/doublespeakgames/adarkroom
版本：1fada46 (2025-05-23)
许可证：Mozilla Public License 2.0（MPL-2.0）

为在内网工作站离线托管，只做了以下**技术性**改动，未修改游戏逻辑、未移除版权声明：

- 移除外部 jQuery（改用仓库自带 lib/jquery.min.js）：<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
- Google Tag Manager 外链 → 本地空桩 vendor/offline-empty.js
- 保留上游 LICENSE 原文（LICENSE.md）

> 原仓库的 LICENSE/README 原样保留；本文件仅记录差异。

# 本地化修改记录 · Javascript Racer

来源：https://github.com/jakesgordon/javascript-racer
版本：3e8a060 (2025-06-01)
许可证：MIT License（MIT）

为在内网工作站离线托管，只做了以下**技术性**改动，未修改游戏逻辑、未移除版权声明：

- 保留上游 LICENSE 原文（LICENSE）

> 原仓库的 LICENSE/README 原样保留；本文件仅记录差异。

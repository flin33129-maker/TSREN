# 本地化修改记录 · Hextris

来源：https://github.com/Hextris/hextris
版本：3f4847d (2022-02-08)
许可证：GNU GPL v3.0（GPL-3.0）

为在内网工作站离线托管，只做了以下**技术性**改动，未修改游戏逻辑、未移除版权声明：

- 移除 Google AdSense 广告脚本
- 移除 Google Fonts（Exo 2）外链，改用系统字体栈
- JS 动态注入的 hextris.io 统计脚本 → 本地空桩
- 保留上游 LICENSE 原文（LICENSE.md）

> 原仓库的 LICENSE/README 原样保留；本文件仅记录差异。

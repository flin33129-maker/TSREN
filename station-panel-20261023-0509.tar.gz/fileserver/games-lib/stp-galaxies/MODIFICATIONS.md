# 本地化修改记录 · Galaxies

来源：https://www.chiark.greenend.org.uk/~sgtatham/puzzles/js/
版本：20260923.616da16
许可证：MIT License（MIT）

为在内网工作站离线托管，只做了以下**技术性**改动，未修改游戏逻辑、未移除版权声明：

- 官方 Emscripten/WebAssembly 构建原样托管（index.html 由 galaxies.html 改名）

> 原仓库的 LICENSE/README 原样保留；本文件仅记录差异。

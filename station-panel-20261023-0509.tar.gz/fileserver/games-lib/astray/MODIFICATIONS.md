# 本地化修改记录 · Astray

来源：https://github.com/wwwtyro/Astray
版本：d3c4f61 (2022-08-13)
许可证：The Unlicense（公有领域）（Unlicense）

为在内网工作站离线托管，只做了以下**技术性**改动，未修改游戏逻辑、未移除版权声明：

- 纹理绝对路径 /xxx.png → 相对路径（部署在 /games/astray/ 子目录，绝对路径会 404）
- 保留上游 LICENSE 原文（LICENSE.md）

> 原仓库的 LICENSE/README 原样保留；本文件仅记录差异。

# 本地化修改记录 · Particle Clicker

来源：https://github.com/particle-clicker/particle-clicker
版本：d6762d5 (2023-03-14)
许可证：MIT License（MIT）

为在内网工作站离线托管，只做了以下**技术性**改动，未修改游戏逻辑、未移除版权声明：

- Font Awesome CSS → 本地 vendor/font-awesome/（MIT + SIL OFL 1.1）
- jQuery 2.1.1 → 本地 vendor/jquery.min.js（MIT）
- AngularJS 1.3 → 本地 vendor/angular.min.js（MIT）
- Bootstrap 3.3.1 JS → 本地 vendor/bootstrap.min.js（MIT）
- Google Analytics 外链 → 本地空桩
- 保留上游 LICENSE 原文（LICENSE）
- 内置第三方库 vendor/jquery.min.js
- 内置第三方库 vendor/angular.min.js
- 内置第三方库 vendor/bootstrap.min.js
- 内置第三方库 vendor/font-awesome/css/font-awesome.min.css
- 内置第三方库 vendor/font-awesome/fonts/fontawesome-webfont.woff

> 原仓库的 LICENSE/README 原样保留；本文件仅记录差异。

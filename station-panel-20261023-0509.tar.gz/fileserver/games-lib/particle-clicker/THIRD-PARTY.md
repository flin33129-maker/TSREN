# 第三方库与许可（Particle Clicker 本地化）

本项目原始 HTML 从 CDN 加载以下库；为离线可用已内置到 vendor/，许可与版权声明保留：

| 库 | 版本 | 许可 | 版权 |
| --- | --- | --- | --- |
| jQuery | 2.1.1 / 1.10.1 | MIT | jQuery Foundation and other contributors |
| AngularJS | 1.3.0-beta.17 | MIT | Google Inc. |
| Bootstrap (JS) | 3.3.1 | MIT | Twitter, Inc. / Bootstrap Authors |
| Font Awesome | 4.2.0 | CSS: MIT / 字体: SIL OFL 1.1 | Dave Gandy |

各上游 LICENSE 原文可从 cdnjs 对应版本目录获取；本工作站仅内网使用，不做再分发。

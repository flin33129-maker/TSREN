# 本地化修改记录 · 2048

来源：https://github.com/gabrielecirulli/2048
版本：478b6ec (2024-10-24)
许可证：MIT License（MIT）

为在内网工作站离线托管，只做了以下**技术性**改动，未修改游戏逻辑、未移除版权声明：

- 保留上游 LICENSE 原文（LICENSE.txt）

> 原仓库的 LICENSE/README 原样保留；本文件仅记录差异。

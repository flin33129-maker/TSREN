# 本地化修改记录 · Cube Composer

来源：https://github.com/sharkdp/cube-composer
版本：83e5b66 (2026-10-11)
许可证：MIT License（MIT）

为在内网工作站离线托管，只做了以下**技术性**改动，未修改游戏逻辑、未移除版权声明：

- 移除 Google Fonts（Roboto Condensed）外链，改用系统字体栈
- 移除 GitHub Star 按钮 iframe（外部请求）
- 内置构建产物 dist/main.js（仓库 .gitignore 了 dist/，取自作者官网）
- 内置构建产物 dist/main.css（仓库 .gitignore 了 dist/，取自作者官网）
- 保留上游 LICENSE 原文（LICENSE）

> 原仓库的 LICENSE/README 原样保留；本文件仅记录差异。

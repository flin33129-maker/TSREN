# 本地化修改记录 · HexGL

来源：https://github.com/BKcore/HexGL
版本：6addc95 (2021-03-21)
许可证：MIT License（MIT）

为在内网工作站离线托管，只做了以下**技术性**改动，未修改游戏逻辑、未移除版权声明：

- favicon 指向本地 favicon.png（去掉 hexgl.bkcore.com 外链）
- Google Analytics 脚本 → 本地空桩
- 保留上游 LICENSE 原文（LICENSE）

> 原仓库的 LICENSE/README 原样保留；本文件仅记录差异。

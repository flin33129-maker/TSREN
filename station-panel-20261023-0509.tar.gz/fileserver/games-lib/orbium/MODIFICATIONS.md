# 本地化修改记录 · Orbium

来源：https://github.com/bni/orbium
版本：d49c4a4 (2024-08-21)
许可证：GNU GPL v2.0（GPL-2.0）

为在内网工作站离线托管，只做了以下**技术性**改动，未修改游戏逻辑、未移除版权声明：

- 保留上游 LICENSE 原文（LICENSE）

> 原仓库的 LICENSE/README 原样保留；本文件仅记录差异。

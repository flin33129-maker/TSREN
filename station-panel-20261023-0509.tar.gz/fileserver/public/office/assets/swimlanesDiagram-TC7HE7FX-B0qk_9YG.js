import{c as r,s as e}from"./flowDiagram-KWPJA3E3-C1gi6UXG.js";import{_ as a}from"./mermaid.core-B3xhDRb8.js";import"./index-BuF-ksn9.js";import"./chunk-5VM5RSS4-D8dr6ijw.js";import"./chunk-XXDRQBXY-DEdRBJ-N.js";import"./chunk-WEXAMYUT-Drzec5mT.js";import"./chunk-GWA4HPMP-TRLoHFwW.js";import"./channel-KfkPrRtd.js";var o=a(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,u=r({styles:s});export{u as diagram};
